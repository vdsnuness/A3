import { getColorIterator } from "./utils/colors/color.js"
import sample from "./examples/widget07.js"
import shape from "./utils/shape/shape.js"

function widget(key, draw) {
    
    let nextColor = getColorIterator(key)

    //draw.rect().size(500,500).move(250,250).fill(nextColor())
    //draw.circle().size(350).move(400,325).fill(nextColor()).opacity(0.5)
    //draw.circle().size(350).move(250,325).fill(nextColor()).opacity(0.5)
    
    // Descomente linha abaixo para ver exemplo 0
    sample(key,draw)

    // let shape1 = shape(44)
    // let shape2 = shape(45)
    // let shape3 = shape(44)
    // shape1.fill(nextColor()).move(500, 500).size(100)
    // shape1.addTo(draw)

    // for(let i=0; i < 15; i++) {
    //     let s = shape(i+50)
    //     s.fill('blue').move(0+i*100, 100).size(100)
    //     s.addTo(draw)      
    // }

    // let s1 = shape(1)
    // console.log(s1)
    // s1.fill('blue').move(100, 500).size(100)
    // s1.addTo(draw)   
    


}

export default widget