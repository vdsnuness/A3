import { getColorIterator } from "../utils/colors/color.js"
import shape from "../utils/shape/shape.js"

export default function (key, draw) {
    
    let nextColor = getColorIterator(key)

    for(let x=0; x < 4; x++) {   
        for(let y=0; y < 4; y++) {
            function nextOpacity() {
                return key.next256() / 256; // Normaliza o valor retornado por next256 para o intervalo [0, 1]
            }
            let newkey = key.next256()
            let t = shape(newkey)
      
            t.fill(nextColor()).opacity(0.6)
            t.move(40+x*260, 25+y*260).size(150)
            t.addTo(draw)   

            let t1 = shape(newkey)
        
            t1.fill(nextColor())
            t1.opacity(nextOpacity())
            t1.move(x*260, y*260).size(70)
            t1.addTo(draw)  

            // let t2 = shape(newkey)

            // t2.fill(nextColor()).opacity(0.6)
            // t2.move(x*260, y*260).size(50)
            // t2.addTo(draw)   

            // let t3 = shape(newkey)
        
            // t3.fill(nextColor()).opacity(1)
            // t3.move(x*260, y*260).size(50)
            // t3.addTo(draw)  

            

            // let t4 = shape(newkey)
            // .fill(nextColor())
            // .opacity(nextOpacity())
            // .size(key.next256()); // Define o tamanho do shape utilizando o método next
        
            // t4.move(40+x*260, 25+y*260);
            // t4.addTo(draw);

 

        }  
        
    }

}
