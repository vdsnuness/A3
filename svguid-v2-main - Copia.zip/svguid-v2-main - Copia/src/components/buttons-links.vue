<template>
    <div class="flex lg:flex-row md:flex-col">
        <button class="bg-gray-100 inline-flex py-3 px-5 rounded-lg items-center hover:bg-gray-200 focus:outline-none">
            <Icon icon="mdi:github" class="text-4xl" />
            <span class="ml-4 flex items-start flex-col leading-none">
                <span class="text-xs text-gray-600 mb-1">
                    svguid on
                </span>
                <span class="title-font font-medium">
                    Github
                </span>
            </span>
        </button>
        <button
            class="bg-gray-100 inline-flex py-3 px-5 rounded-lg items-center lg:ml-4 md:ml-0 ml-4 md:mt-4 mt-0 lg:mt-0 hover:bg-gray-200 focus:outline-none">
            <Icon icon="mdi:github" class="text-4xl" />
            <span class="ml-4 flex items-start flex-col leading-none">
                <span class="text-xs text-gray-600 mb-1">
                    Project
                </span>
                <span class="title-font font-medium">
                    Github
                </span>
            </span>
        </button>
    </div>
</template>
<script>
export default {

}
</script>
<style lang="">

</style>